const express = require('express')

const { ROUTES } = require("./routes");

const { setupLogging } = require("./logging");
const { setupRateLimit } = require("./ratelimit");
const { setupCreditCheck } = require("./creditcheck");
const { setupProxies } = require("./proxy");
const { setupAuth } = require("./auth");
var fs = require('fs');
var http = require('http');
var https = require('https');
var privateKey = fs.readFileSync('./sslcert/server2.key', 'utf8');
var certificate = fs.readFileSync('./sslcert/server2.cert', 'utf8');



var credentials = { key: privateKey, cert: certificate };
const app = express();


//setupLogging(app);
// setupRateLimit(app, ROUTES);
// setupAuth(app, ROUTES);
// setupCreditCheck(app, ROUTES);
setupProxies(app, ROUTES);

// app.listen(port, () => {
//     console.log(`Example app listening at http://localhost:${port}`)
// })

var httpServer = http.createServer(app);
var httpsServer = https.createServer(credentials, app);

httpServer.listen(3002, () => {
    console.log(
        "Example app listening on port 3000!"
    );
});

httpsServer.listen(443, () => {
    console.log(
        "Example app listening on port 443"
    );
});