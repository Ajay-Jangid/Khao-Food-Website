const { createProxyMiddleware } = require('http-proxy-middleware');




const setupProxies = (app, routes) => {
    routes.forEach(r => {

        // let option = {
        //     target: "",
        //    // changeOrigin: true,
        //     onProxyReq: function onProxyReq(proxyReq, req, res) {
        //         proxyReq.setHeader('Authorization', `Basic YWRtaW46ZkdXQm9rS3BhNVc5`)
        //       },
        // }

        app.use(r.url, createProxyMiddleware(r.proxy));
    })
}

exports.setupProxies = setupProxies
