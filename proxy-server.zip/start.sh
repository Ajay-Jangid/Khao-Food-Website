#!/bin/sh
nohup node server.js > output1.log &