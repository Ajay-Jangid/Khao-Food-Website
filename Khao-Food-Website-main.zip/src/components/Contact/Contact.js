
const Contact = () => {
    return (
        <div>
            <h1>Contact Us</h1>
            <p>Contact Page</p>
        </div>
    )
}

export default Contact;