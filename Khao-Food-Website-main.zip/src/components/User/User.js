import "./User.css"
const User = () => {
    return (
        <div className="user-card">
            <h2>Name: Ajay</h2>
            <h3>Location: Pune</h3>
            <h4>Contact: @Ajayjangid07</h4>
        </div>
    )
}

export default User;