
const Grocery = () => {
    return (
        <div>
            <h1>This is our Grocery Page.</h1>
        </div>
    )
}

export default Grocery;